/*
 * Copyright 2025 Marc Liberatore.
 */

package hello;

public class Hello {
	public static String helloString() {

	    return "Hello, CICS 210 Data Structures World!";
	}

	public static void main(String[] args) {
		System.out.println(helloString());
	}

}
